package logica;

public class Estudiante extends Usuario {
	
	// Constructor de Estudiante

	Estudiante(int ci, String nombre, String apellido, String mail, String password) {
		super(ci, nombre, apellido, mail, password);
	}
}
