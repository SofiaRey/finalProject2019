package logica;

public class Bibliotecario extends Usuario {
	
	// Constructor de Bibliotecario

	Bibliotecario(int ci, String nombre, String apellido, String mail, String password) {
		super(ci, nombre, apellido, mail, password);
	}

}
